export const brl = (v: number | string | null | undefined) =>
  Number(v ?? 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

/** Accepts a raw code or an invite link (?ref=CODE) and returns the normalized code. */
export function parseReferral(input: string): string {
  const s = input.trim();
  if (!s) return "";
  try {
    const url = new URL(s);
    const ref = url.searchParams.get("ref");
    if (ref) return ref.trim().toUpperCase();
  } catch {
    /* not a URL */
  }
  const m = s.match(/ref=([A-Za-z0-9]+)/);
  return (m?.[1] ?? s).toUpperCase();
}
