import { describe, it, expect } from "vitest";
import { parseReferral } from "./format";

describe("parseReferral", () => {
  it("accepts a raw code", () => expect(parseReferral(" ab12cd34 ")).toBe("AB12CD34"));
  it("accepts an invite link", () =>
    expect(parseReferral("https://site.app/auth?ref=ab12cd34")).toBe("AB12CD34"));
});
